"""Shared code for the ECE 285 Medusa calibration project."""
